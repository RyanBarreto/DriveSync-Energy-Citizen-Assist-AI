# Testes de compreensão e utilidade — preencher após executar

**Status:** ainda não realizados. Este arquivo é um protocolo, não evidência de testes.

## Procedimento sugerido
Convidar 3–5 pessoas (preferencialmente alguém com experiência administrativa/técnica e usuários leigos). Sem coletar nomes, e-mails ou dados pessoais. Pedir que cada participante: (1) descubra o consumo mensal; (2) compare rede e solar; (3) pergunte ao assistente sobre limitações; (4) explique com suas palavras se a economia é garantida.

## Registro a preencher
| Participante anônimo | Data | Tarefa | Conseguiu? | Comentário literal ou resumo fiel | Ajuste realizado |
|---|---|---|---|---|---|
| P01 | PENDENTE | PENDENTE | PENDENTE | PENDENTE | PENDENTE |
| P02 | PENDENTE | PENDENTE | PENDENTE | PENDENTE | PENDENTE |
| P03 | PENDENTE | PENDENTE | PENDENTE | PENDENTE | PENDENTE |

## Critérios
A pessoa identifica unidade kWh e período; compreende que números são hipóteses; distingue geração solar de economia financeira; encontra referências; consegue usar o assistente. Após testes, registrar os ajustes reais realizados, mesmo que sejam pequenos.
