// Execute: node testes/teste_calculos.js
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const sandbox={module:{exports:{}},document:{getElementById:()=>({addEventListener(){},reportValidity(){return true},value:'1',style:{},textContent:''})}};
vm.runInNewContext(fs.readFileSync('energy.js','utf8'),sandbox);
const {compute}=sandbox.module.exports;
const r=compute({lights:4,'light-w':30,sensors:2,'sensor-w':25,'control-w':30,tariff:.9,kwp:1,sun:4.5,pr:.75,invest:6500,maint:150,eff:20});
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
close(r.power,200);close(r.consumption,144);close(r.gridCost,129.6);close(r.solarGeneration,101.25);close(r.solarSaving,91.125);close(r.efficiencySaving,25.92);close(r.payback,6500/(91.125*12-150));
const noSolar=compute({...r.v,kwp:0});close(noSolar.solarSaving,0);
const surplus=compute({...r.v,kwp:50});close(surplus.solarUsed,144);
console.log('OK: 9 verificações dos cálculos energéticos.');
