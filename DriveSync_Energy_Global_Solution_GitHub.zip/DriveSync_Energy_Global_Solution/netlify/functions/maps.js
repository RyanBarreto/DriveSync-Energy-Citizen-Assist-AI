// Netlify Function — Google Routes API
// Configure GOOGLE_MAPS_API_KEY in Netlify > Site configuration > Environment variables.
// This function runs server-side; never expose the Google API key in browser JavaScript.

exports.handler = async function (event) {
  const apiKey = process.env.GOOGLE_MAPS_API_KEY;

  if (!apiKey) {
    return jsonResponse(500, { error: 'A variável GOOGLE_MAPS_API_KEY não está configurada na Netlify.' });
  }

  const rua = event.queryStringParameters?.rua?.trim();

  if (!rua) {
    return jsonResponse(400, { error: 'Informe o parâmetro rua.' });
  }

  const body = {
    origin: { address: rua },
    // Destino de referência recebido no exemplo inicial do projeto.
    // Para calcular outro trajeto, altere este destino ou passe-o como parâmetro validado.
    destination: { address: 'Avenida Paulista, 2000, São Paulo, SP, Brasil' },
    travelMode: 'DRIVE',
    routingPreference: 'TRAFFIC_AWARE',
    languageCode: 'pt-BR',
    regionCode: 'BR'
  };

  try {
    const response = await fetch('https://routes.googleapis.com/directions/v2:computeRoutes', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': apiKey,
        'X-Goog-FieldMask': 'routes.duration,routes.staticDuration,routes.distanceMeters,routes.legs.startLocation'
      },
      body: JSON.stringify(body)
    });

    const data = await response.json();

    if (!response.ok) {
      const message = data.error?.message || 'O Google Maps Routes API recusou a solicitação.';
      return jsonResponse(response.status, { error: message });
    }

    return jsonResponse(200, data);
  } catch (error) {
    console.error('Falha ao consultar Google Routes API:', error);
    return jsonResponse(502, { error: 'Não foi possível se comunicar com o Google Maps.' });
  }
};

function jsonResponse(statusCode, payload) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store'
    },
    body: JSON.stringify(payload)
  };
}
