# Análise energética — DriveSync Energy

## Contexto e público
Público-alvo: gestores municipais e equipes de manutenção de infraestrutura semafórica. Necessidade: estimar a energia consumida por conjuntos semafóricos, sensores e controle, e orientar decisões sobre fonte renovável e eficiência. Não há instalação física nem medição de campo nesta versão.

## Origem e qualidade dos dados
Os dados do arquivo `dados/premissas_exemplo.csv` são **100% hipóteses didáticas**, não medições reais. Antes da entrega final, substituir ou justificar valores com documentação: fichas técnicas de semáforos e sensores; tarifa publicada da distribuidora; irradiação local do CRESESB; preços de cotações de fornecedores. Registrar data de acesso, URL e unidade de cada valor validado.

## Período comum: 30 dias
Operação considerada: 24 horas/dia, 30 dias/mês, potência média constante. Todas as alternativas usam a mesma necessidade e o mesmo período.

1. Potência média (W): `P = N_semaforos × W_semaforo + N_sensores × W_sensor + W_controle`.
2. Energia mensal (kWh): `E = P × 24 × 30 / 1000`.
3. Custo variável da rede (R$): `C = E × tarifa_R$/kWh`.
4. Geração fotovoltaica potencial (kWh/mês): `G = kWp × horas_sol_pleno_por_dia × 30 × fator_desempenho`.
5. Energia solar aproveitada: `A = min(E,G)`; excedente não monetizado.
6. Economia solar variável: `A × tarifa`; custo residual variável: `(E-A) × tarifa`.
7. Alternativa de equipamentos eficientes: `E_ef = E × (1-reducao_percentual/100)`; economia = `(E-E_ef) × tarifa`.
8. Retorno simples solar (anos): `investimento / (12 × economia_mensal_solar - manutencao_anual)` apenas se denominador positivo.

## Exemplo numérico — exclusivamente ilustrativo
Quatro conjuntos de 30 W, dois sensores de 25 W e controle de 30 W = **200 W**. Consumo: **144 kWh/mês**. Tarifa hipotética R$ 0,90/kWh → **R$ 129,60/mês**. Solar 1 kWp, 4,5 h/dia e desempenho 0,75 → **101,25 kWh/mês**, com economia potencial de **R$ 91,13/mês**. Rede residual: **R$ 38,48/mês**. Eficiência de 20% → economia de **28,8 kWh** e **R$ 25,92/mês**. Investimento R$ 6.500 e manutenção R$ 150/ano → retorno simples ≈ **6,89 anos**. Valores arredondados na apresentação; cálculos internos não são arredondados.

## Comparação de viabilidade e impactos
| Alternativa | Investimento | Operação | Viabilidade | Impactos/limitações |
|---|---|---|---|---|
| Rede elétrica | conexão existente | paga tarifa | infraestrutura já conectada | depende da matriz e da rede, sofre interrupções |
| Rede + fotovoltaica | módulos, inversor, instalação, manutenção | reduz compra variável | requer área, insolação, projeto elétrico e conformidade | geração intermitente, fabricação e descarte; sem bateria não garante autonomia |
| Equipamentos eficientes | substituição de dispositivos | reduz potência | depende de compatibilidade e vida útil | reduz consumo, mas requer fabricação e descarte de equipamentos |

**Importante:** o comparativo monetário simplificado não inclui custos de substituição dos equipamentos eficientes; não permite comparar payback dessa terceira alternativa. O modelo também não calcula emissões de CO₂ por falta de fator de emissão validado. Não atribuir redução de consumo elétrico apenas à alteração dos tempos de verde.

## Limitações
Não há coleta real de sensores, geração solar medida, orçamento contratado ou comprovação de economia efetiva. Tarifa variável não representa a conta integral. Não inclui demanda contratada, custos fixos, tributos, compensação de créditos, perdas adicionais, degradação, sombreamento, sazonalidade, armazenamento, financiamento, riscos regulatórios ou interrupções. A comparação de custos só é válida sob as premissas explicitadas.

## Referências para consulta e validação
- ANEEL: https://www.gov.br/aneel/pt-br — regulação, tarifas e geração distribuída.
- CRESESB/CEPEL: https://cresesb.cepel.br/ — dados e ferramentas para potencial solar.
- EPE: https://www.epe.gov.br/ — estatísticas e balanço energético.
- Fichas técnicas e cotações de equipamentos: **pendente de coleta pelo grupo**.
- Tarifa específica e irradiação do município: **pendente de validação pelo grupo**.

Os links indicam instituições de referência; **não** comprovam os valores hipotéticos usados no exemplo. Documentar páginas, datas e parâmetros efetivamente consultados antes de apresentar valores como reais.
