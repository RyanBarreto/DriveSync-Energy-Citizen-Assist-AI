# Roteiro técnico — vídeo não listado, máximo 3 minutos

**Título sugerido:** DriveSync Energy | Citizen Assist AI — Global Solution

| Tempo | Imagem/ação | Narração sugerida |
|---|---|---|
| 00:00–00:20 | Tela inicial DriveSync e cruzamento | “Somos a equipe [integrantes]. Nosso público são gestores e equipes que operam cruzamentos urbanos. Além de organizar o trânsito, essa infraestrutura consome eletricidade continuamente.” |
| 00:20–00:42 | Abrir seção 07 / Energia | “Criamos o DriveSync Energy, um módulo do Citizen Assist AI que compara opções para suprir o consumo de semáforos, sensores e equipamentos de controle.” |
| 00:42–01:10 | Mostrar campos de potência e consumo | “No exemplo didático, quatro semáforos de 30 watts, dois sensores de 25 watts e controle de 30 watts somam 200 watts. Operando 24 horas por dia, durante 30 dias, consomem 144 quilowatts-hora. Com tarifa hipotética de 90 centavos, o custo variável é R$ 129,60.” |
| 01:10–01:40 | Mostrar cenário solar e gráfico | “A primeira opção é usar a rede elétrica. A segunda acrescenta um sistema solar de 1 quilowatt-pico. Com 4,5 horas de sol pleno por dia e fator de desempenho de 75%, a geração estimada é de 101,25 quilowatts-hora por mês. O modelo calcula economia potencial de cerca de R$ 91,13 por mês.” |
| 01:40–02:02 | Mostrar eficiência, retorno e limitações | “Também comparamos equipamentos 20% mais eficientes, que reduziriam 28,8 quilowatts-hora mensais. Para o solar, o retorno simples estimado é de aproximadamente 6,89 anos, sob as hipóteses adotadas. Não incluímos custos fixos, baterias e outras condições de instalação.” |
| 02:02–02:30 | Perguntar ao assistente “Vale a pena instalar energia solar?” | “O Citizen Assist AI usa os resultados da calculadora para responder perguntas sobre consumo, custos, energia solar e impactos ambientais. As respostas mostram fórmulas, fontes de referência e limites das estimativas.” |
| 02:30–02:45 | Mostrar referências e testes | “As instituições de referência são ANEEL, CRESESB e EPE. Os valores iniciais são hipotéticos e devem ser validados com fichas técnicas, tarifa local e irradiação. Registramos os testes de compreensão com usuários no repositório.” |
| 02:45–03:00 | Mostrar GitHub e conclusão | “O código, os cálculos, os dados e os testes estão organizados no GitHub. Nosso objetivo é apoiar decisões de infraestrutura mais transparentes e sustentáveis.” |

## Gravação e conferência
- Gravar em 1080p, preferencialmente com captura de tela e voz legível.
- Ensaiar para não ultrapassar **03:00**; se necessário, encurtar a abertura.
- Mostrar o assistente funcionando e um cálculo sendo alterado ao vivo.
- Não dizer que os valores foram medidos nem que a economia é garantida.
- Mostrar evidências de testes **apenas depois** de realmente realizados.
- Publicar no YouTube como **Não listado** e verificar o link em janela anônima.
